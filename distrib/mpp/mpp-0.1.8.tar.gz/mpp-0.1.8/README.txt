(* OASIS_START *)
(* DO NOT EDIT (digest: 0823361eb1154c5ce76334bff87233e3) *)

mpp - A preprocessor meant to blend languages.
==============================================

MPP is a meta processor that is meant to bring any programming language to
the preprocessing level. You can easily use OCaml as a preprocessor language
for any text-based document. If you want to use another language, you just
need to tell MPP how to use it. MPP also works as a simple preprocessor, as
it provides its own (tiny) language.

See the file [INSTALL.txt](INSTALL.txt) for building and installation
instructions.

[Home page](https://github.com/ocaml/MPP-language-blender)

Copyright and license
---------------------

mpp is distributed under the terms of the Internet Software Consortium's
license.

(* OASIS_STOP *)
