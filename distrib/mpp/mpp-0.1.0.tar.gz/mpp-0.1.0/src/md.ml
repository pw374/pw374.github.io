module Lmap = struct
  include Map.Make(struct
    type t = char
    let compare = Pervasives.compare
  end)
end

let readers =
  ref Lmap.empty

module CS = Mpp_charstream
module MD = struct
  type 'a t = 'a
end

let register_reader 
    (c : char)
    (r : CS.t -> 'a list Lmap.t ->
      ('md MD.t * CS.t * 'a list Lmap.t)) =
  readers := Lmap.add c r !readers

(* ************************************************ *)

[
  "######", (fun cs -> `H6(cs#read));
  "#####", (fun cs -> `H5(cs#read));
  "####", (fun cs -> `H4(cs#read));
  "###", (fun cs -> `H3(cs#read));
  "##", (fun cs -> `H2(cs#read));
  "#", (fun cs -> `H1(cs#read));
  "**", `Maybe (fun cs -> `Strong(cs#read));
]

