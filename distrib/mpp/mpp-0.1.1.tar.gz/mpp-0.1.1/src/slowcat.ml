let _ =
(try ignore(Unix.select [] [] [] 0.5) with _ -> ());
try while true do
print_endline(read_line());
(try ignore(Unix.select [] [] [] 0.5) with _ -> ())
done with End_of_file -> ()
