{< >}
(* $Id: ml-insert.ml,v 1.1 2006/08/26 01:08:18 philippej Exp $ *)

x

{< let x = 42
   let y = 222 >}

cdskl

(* end of plop.ml                                              *)
