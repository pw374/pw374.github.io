frag
====

extract fragments from files
