(* OASIS_START *)
(* DO NOT EDIT (digest: 4bea98684e72fe53d8f8386676bca575) *)
This is the README file for the omd distribution.

A Markdown frontend in pure OCaml.

This Markdown library is implemented using only pure OCaml (including I/O
operations provided by the standard OCaml compiler distribution). Omd targets
the original Markdown with a few Github markdown features.

See the files INSTALL.txt for building and installation instructions. 

Home page: https://github.com/pw374/omd


(* OASIS_STOP *)
