(***********************************************************************)
(* omd: Markdown frontend in OCaml                                     *)
(* (c) 2013 by Philippe Wang <philippe.wang@cl.cam.ac.uk>              *)
(* Licence : ISC                                                       *)
(* http://www.isc.org/downloads/software-support-policy/isc-license/   *)
(***********************************************************************)

(* xtxt = eXTernal eXTension *)

(* let extensions = ref [] *)

(* let get () = *)
(*   !extensions *)

(* let register e = *)
(*   extensions := e :: !extensions *)

(* let set es = extensions := es *)

(* let activate ... *)

(* (\* let deactivate ... *\) *)

(* priority (integer?) *)
(* pre-extension *)
(* post-extension *)


