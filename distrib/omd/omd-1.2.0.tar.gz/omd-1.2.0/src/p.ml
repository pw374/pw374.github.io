     List.iter (fun (a,b,c) ->
     print_endline ("let read_until_"^a^" ?(bq=false) ?(no_nl=false) l =
     assert_well_formed l;
     let rec loop accu n = function
      | Backslash :: ("^b^" as b) :: tl ->
        loop (b::accu) n tl
      | Backslash :: ("^b^"s 0) :: tl ->
        loop ("^b^"::accu) n ("^b^"::tl)
      | Backslashs 0 :: tl ->
        loop (Backslash::accu) n tl
      | Backslashs 1 :: tl ->
        loop (Backslash::accu) n (Backslash::tl)
      | Backslashs 2 :: tl ->
        loop (Backslashs 0::accu) n tl
      | (Backslashs x) :: tl ->
        if x mod 2 = 0 then
          loop (Backslashs(x/2-1)::accu) n tl
        else
          loop (Backslashs(x/2-1)::accu) n (Backslash::tl)
      | (Backquote|Backquotes _ as e)::tl as l ->
        if bq then
          match bcode [] [] l with
          | None -> loop (e::accu) n tl
          | Some (r, _, tl) ->
            loop (* not very pretty kind of hack *)
              (List.rev(L.lex(Omd_backend.markdown_of_md r))@accu)
              n
              tl
        else
         loop (e::accu) n tl"
      ^(if c<>"" then "
      | Backslash :: ("^c^" as b) :: tl ->
        loop (b::accu) n tl
      | Backslash :: ("^c^"s 0) :: tl ->
        loop ("^c^"::accu) n ("^c^"::tl)
      | "^c^" as e :: tl ->
        loop (e::accu) (n+1) tl
      | "^c^"s x as e :: tl ->
        loop (e::accu) (n+x+2) tl
     " else "")^
     "    | "^b^" as e :: tl ->
        if n = 0 then
          List.rev accu, tl
        else
          loop (e::accu) (n-1) tl
      | "^b^"s 0 :: tl ->
        if n = 0 then
          List.rev accu, "^b^"::tl
        else
          loop ("^b^"::accu) (n-1) ("^b^"::tl)
      | "^b^"s x :: tl ->
        if n = 0 then
          List.rev accu, "^b^"s(x-1)::tl
        else
          loop
            (match accu with
             | "^b^"::accu -> "^b^"s(0)::accu
             | "^b^"s x::accu -> "^b^"s(x+1)::accu
             | _ -> "^b^"::accu)
            (n-1)
            ("^b^"s(x-1)::tl)
      | (Newline|Newlines _ as e)::tl ->
        if no_nl then
          raise NL_exception
        else
          loop (e::accu) n tl
      | e::tl ->
        loop (e::accu) n tl
      | [] ->
        raise Premature_ending
     in
     if debug then
       eprintf \"Omd_parser.read_until_"^a^" %S bq=%b no_nl=%b\\n%!\" (L.string_of_tokens l) bq no_nl;
     let res = loop [] 0 l in
     if debug then
       eprintf \"Omd_parser.read_until_"^a^" %S bq=%b no_nl=%b => %S\\n%!\" (L.string_of_tokens l) bq no_nl (L.string_of_tokens (fst res));
     res
"))

     [ "gt", "Greaterthan", "Lessthan";
     "lt", "Lessthan", "";
     "cparenth", "Cparenthesis", "Oparenthesis";
     "oparenth", "Oparenthesis", "";
     "dq", "Doublequote", "";
     "q", "Quote", "";
     "obracket", "Obracket", "";
     "cbracket", "Cbracket", "Obracket";
     "space", "Space", "";
     ]
